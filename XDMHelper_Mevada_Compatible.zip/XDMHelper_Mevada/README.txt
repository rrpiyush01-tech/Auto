X DM Helper v1.1 - Mevada-compatible build

Upload this folder/project as a ZIP to an Android Gradle build service.
Build target: APK (debug)
Java-only Android project; no Kotlin dependency.
Requires Android Gradle Plugin 8.7.3 and compileSdk 35.

This helper uses Android Accessibility to inspect visible X UI. It only auto-opens the first visible conversation and detects visible X links. Repost and Send remain manual confirmation actions.
