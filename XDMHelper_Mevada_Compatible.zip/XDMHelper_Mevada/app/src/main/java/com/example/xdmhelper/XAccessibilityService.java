package com.example.xdmhelper;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.graphics.Rect;
import android.os.SystemClock;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class XAccessibilityService extends AccessibilityService {
    public static java.util.function.Consumer<String> status;
    private static final Pattern URL = Pattern.compile("https?://(?:www\\.)?(?:x\\.com|twitter\\.com)/[^\\s]+", Pattern.CASE_INSENSITIVE);
    private static final String XPKG = "com.twitter.android";
    private static long lastWindow = 0L, lastOpened = 0L;
    private static String lastUrl = "";

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null || !XPKG.equals(event.getPackageName().toString())) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        long now = SystemClock.uptimeMillis();

        List<String> texts = new ArrayList<>();
        collectText(root, texts);
        boolean chatList = false, unread = false;
        for (String s : texts) {
            if (s.equalsIgnoreCase("Chat") || s.toLowerCase().contains("chats")) chatList = true;
            if (s.equalsIgnoreCase("Unread") || s.toLowerCase().contains("unread")) unread = true;
        }
        chatList = chatList && unread;

        if (chatList && now - lastOpened > 1500 && getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("autoOpen", true)) {
            if (clickFirstConversation(root)) {
                lastOpened = now;
                sendStatus("Opened first visible conversation");
                return;
            }
        }

        String found = scanForUrl(root);
        if (found != null && !found.equals(lastUrl)) {
            lastUrl = found;
            sendStatus("X link detected: " + found);
        } else if (!chatList && now - lastWindow > 1000) {
            lastWindow = now;
            sendStatus("X screen detected");
        }
    }

    private void sendStatus(String s) { if (status != null) status.accept(s); }

    private void collectText(AccessibilityNodeInfo n, List<String> out) {
        CharSequence t = n.getText();
        if (t != null && t.length() > 0) out.add(t.toString());
        for (int i=0; i<n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null) collectText(c, out);
        }
    }

    private String scanForUrl(AccessibilityNodeInfo n) {
        CharSequence t = n.getText();
        if (t != null) {
            Matcher m = URL.matcher(t.toString());
            if (m.find()) return m.group();
        }
        for (int i=0; i<n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null) {
                String r = scanForUrl(c);
                if (r != null) return r;
            }
        }
        return null;
    }

    private boolean clickFirstConversation(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> candidates = new ArrayList<>();
        collectClickableTextNodes(root, candidates);
        for (AccessibilityNodeInfo n : candidates) {
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            CharSequence cs = n.getText();
            if (cs == null) continue;
            String t = cs.toString().trim();
            if (r.top < 280 || r.top > 1250) continue;
            if (t.equalsIgnoreCase("Search") || t.equalsIgnoreCase("Unread") || t.equalsIgnoreCase("Chat")) continue;
            if (r.width() < 180 || r.height() < 45) continue;
            if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        }
        return false;
    }

    private void collectClickableTextNodes(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out) {
        if (n.isClickable() && n.getText() != null && n.getText().length() > 0) out.add(n);
        for (int i=0; i<n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null) collectClickableTextNodes(c, out);
        }
    }

    @Override public void onInterrupt() {}
}
