package com.example.xdmhelper;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.text.InputType;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText link;
    private TextView status;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(28,28,28,28);

        TextView title = new TextView(this);
        title.setText("X DM Helper v1.1");
        title.setTextSize(24f);

        link = new EditText(this);
        link.setHint("Your predefined link");
        link.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        link.setText(prefs.getString("replyLink", ""));

        Button save = new Button(this);
        save.setText("Save link");
        Button settings = new Button(this);
        settings.setText("Open Accessibility Settings");

        Switch auto = new Switch(this);
        auto.setText("Auto-open first visible chat");
        auto.setChecked(prefs.getBoolean("autoOpen", true));

        status = new TextView(this);
        status.setText("Status: waiting for X Chat screen");
        status.setTextSize(16f);
        status.setPadding(0,20,0,20);

        save.setOnClickListener(v -> {
            prefs.edit().putString("replyLink", link.getText().toString().trim()).apply();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        });
        settings.setOnClickListener(v -> startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        auto.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("autoOpen", checked).apply());

        XAccessibilityService.status = s -> runOnUiThread(() -> status.setText("Status: " + s));

        box.addView(title);
        box.addView(link);
        box.addView(save);
        box.addView(auto);
        box.addView(settings);
        box.addView(status);
        setContentView(box);
    }
}
